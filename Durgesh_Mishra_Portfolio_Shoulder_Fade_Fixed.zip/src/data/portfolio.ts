/**
 * Central portfolio data — aligned with Durgesh Mishra's supplied resume.
 * Keep factual claims consistent with the resume.
 */
export type Palette = { from: string; via: string; to: string; accent: string };
export const profile = {
  fullName: 'DURGESH MISHRA',
  displayName: 'Durgesh Mishra',
  firstName: 'DURGESH',
  originalLabel: 'THE PORTFOLIO WEBSITE',
  role: 'Computer Science Engineering Student',
  tagline: ['CSE Student', 'Web Development', 'AI-Enabled Applications'],
  intro: 'B.Tech Computer Science Engineering student with foundational knowledge in programming, web development, and AI-enabled applications. Experienced in building student projects, documenting requirements, and collaborating to solve problems.',
  location: 'Gorakhpur, Uttar Pradesh, India',
  email: 'durgesh.mishra7526@gmail.com',
  links: {
    linkedin: 'https://linkedin.com/in/durgesh-mishra-a00714330',
    github: 'https://github.com/DurgeshMishra09',
  },
  resumePdf: '/assets/Durgesh.Mishra-Resume.pdf',
  portrait: {
    src: '/assets/portrait-720.webp',
    srcSet: '/assets/portrait-420.webp 420w, /assets/portrait-720.webp 720w, /assets/portrait-1100.webp 1100w',
    alt: 'Portrait of Durgesh Mishra',
  },
  interests: ['Emerging technologies', 'Programming', 'Logical Reasoning'],
};
export const education = [{
  school: 'Institute of Technology and Management, GIDA, Gorakhpur',
  place: 'Gorakhpur, Uttar Pradesh',
  degree: 'Bachelor of Technology in Computer Science Engineering',
  period: '2024 – 2028 (Expected)',
  score: 'Expected graduation: 2028',
}];
export const experience = [{
  company: 'Codec Technologies Pvt. Ltd.',
  role: 'Web Development Trainee',
  place: 'India',
  period: 'Oct 2025 – Nov 2025',
  points: [
    'Completed an AICTE & ICAC-approved web development training program.',
    'Practised HTML structure and CSS styling to build foundational web layouts.',
    'Collaborated in a team of 3, communicated project requirements, and solved layout challenges.',
  ],
}];
export type Metric = { value: string; label: string };
export type Project = {
  id: string; title: string; year: string; genre: string; logline: string;
  stack: string[]; build: string[]; features: string[]; metrics: Metric[];
  website?: string; github?: string; palette: Palette; motif: 'shield' | 'flow' | 'tenants';
};
const crimson: Palette = { from: '#24060b', via: '#6e0d1d', to: '#09070a', accent: '#ff3d5a' };
const amber: Palette = { from: '#1c1003', via: '#6b3c06', to: '#0a0806', accent: '#ffb547' };
const ocean: Palette = { from: '#04121f', via: '#0f4c6e', to: '#05080d', accent: '#4cc9ff' };
const violet: Palette = { from: '#120822', via: '#3d1a6e', to: '#07060c', accent: '#b98bff' };
const jade: Palette = { from: '#03150f', via: '#0d5a40', to: '#050a08', accent: '#46e3a8' };
export const projects: Project[] = [
  {
    id: 'debunkify', title: 'DEBUNKIFY', year: 'Project', genre: 'AI • Verification • Web App', website: 'https://debunkify-v2.onrender.com',
    logline: 'An AI-powered fake news and image verification project focused on helping users investigate suspicious content.',
    stack: ['React', 'FastAPI', 'Groq API', 'Cloudinary API', 'SerpAPI'],
    build: [
      'Built a verification web app for text/news and reverse-image investigation using a React frontend and FastAPI backend.',
      'Integrated Groq API for AI-assisted analysis, Cloudinary for image handling, and SerpAPI for reverse-image search.',
    ],
    features: ['Text/news verification', 'Image verification workflow', 'AI-assisted analysis', 'Image handling and reverse-image investigation'],
    metrics: [{ value: '2', label: 'verification modes' }, { value: 'React', label: 'frontend' }, { value: 'FastAPI', label: 'backend' }],
    palette: { from: '#2a0610', via: '#7a0f24', to: '#0b0710', accent: '#ff3d5a' }, motif: 'shield',
  },
  {
    id: 'blood-donation', title: 'Blood Donation & Acceptance Management System', year: 'Project', genre: 'Web • Community', website: 'https://durgeshmishra09.github.io/BloodLinkbyDurgesh/',
    logline: 'A responsive registration interface designed to support blood donation and acceptance management.',
    stack: ['HTML', 'CSS', 'JavaScript'],
    build: ['Developed a responsive registration interface for 50+ users using HTML, CSS, and JavaScript.'],
    features: ['Responsive registration interface', 'Blood donation and acceptance information', 'Web-based user interface'],
    metrics: [{ value: '50+', label: 'users supported' }, { value: '3', label: 'web technologies' }],
    palette: { from: '#1a0d02', via: '#8a4a07', to: '#0a0806', accent: '#ffb547' }, motif: 'flow',
  },
  {
    id: 'notes-heaven', title: 'Notes Heaven', year: 'Project', genre: 'Education • Web Platform', website: 'https://notes-heaven.pages.dev',
    logline: 'A responsive AKTU notes website that organizes study resources and links to external downloads.',
    stack: ['HTML', 'CSS', 'JavaScript'],
    build: ['Created a responsive AKTU notes website with subject search, organized resource cards, and external download links using HTML, CSS, and JavaScript.'],
    features: ['Subject search', 'Organized resource cards', 'External download links', 'Responsive design'],
    metrics: [{ value: 'AKTU', label: 'study resources' }, { value: '3', label: 'web technologies' }],
    palette: { from: '#04121f', via: '#0f4c6e', to: '#05080d', accent: '#4cc9ff' }, motif: 'tenants',
  },
];
export type Achievement = { id: string; title: string; org: string; detail: string; laurel: string; link?: string };
export const achievements: Achievement[] = [
  { id: 'ai-for-all', title: 'AI for All', org: 'TCS iON', detail: 'Completed the AI and Cybersecurity Awareness course under the AI for All initiative.', laurel: 'Certification', link: '/certificates/ai-for-all-tcs-ion.pdf' },
  { id: 'codec-training', title: 'Web Development Training', org: 'Codec Technologies Pvt. Ltd.', detail: 'Completed the AICTE & ICAC-approved Web Developer Intern program.', laurel: 'Training', link: '/certificates/codec-technologies-web-development.pdf' },
  { id: 'tata-cyber', title: 'Cybersecurity Analyst Job Simulation', org: 'Tata', detail: 'Completed practical tasks in identity and access management.', laurel: 'Job Simulation', link: '/certificates/tata-cybersecurity-analyst.pdf' },
  { id: 'deloitte-cyber', title: 'Cyber Job Simulation', org: 'Deloitte', detail: 'Completed a cybersecurity job simulation.', laurel: 'Job Simulation', link: '/certificates/deloitte-cyber-job-simulation.pdf' },
  { id: 'mastercard-cyber', title: 'Cybersecurity Job Simulation', org: 'Mastercard', detail: 'Completed phishing simulation and result interpretation tasks.', laurel: 'Job Simulation', link: '/certificates/mastercard-cybersecurity-job-simulation.pdf' },
  { id: 'simplilearn-full-stack', title: 'Full-Stack Development 101', org: 'Simplilearn', detail: 'Completed the Full-Stack Development 101 learning program.', laurel: 'Certification', link: '/certificates/simplilearn-full-stack-development-101.pdf' },
  { id: 'morrow-hackathon', title: 'Morrow 1.0 Hackathon', org: 'Unstop / MnM', detail: 'Certificate of participation in the Morrow 1.0 open-source hackathon.', laurel: 'Achievement', link: '/certificates/morrow-1-hackathon.pdf' },
];
export type Certification = { issuer: string; name: string; link: string };
export const certifications: Certification[] = [
  { issuer: 'TCS iON', name: 'AI for All', link: '/certificates/ai-for-all-tcs-ion.pdf' },
  { issuer: 'Codec Technologies Pvt. Ltd.', name: 'Web Development Training Certificate', link: '/certificates/codec-technologies-web-development.pdf' },
  { issuer: 'Tata', name: 'Cybersecurity Analyst Job Simulation', link: '/certificates/tata-cybersecurity-analyst.pdf' },
  { issuer: 'Deloitte', name: 'Cyber Job Simulation', link: '/certificates/deloitte-cyber-job-simulation.pdf' },
  { issuer: 'Mastercard', name: 'Cybersecurity Job Simulation', link: '/certificates/mastercard-cybersecurity-job-simulation.pdf' },
  { issuer: 'Simplilearn', name: 'Full-Stack Development 101', link: '/certificates/simplilearn-full-stack-development-101.pdf' },
  { issuer: 'Unstop / MnM', name: 'Morrow 1.0 Hackathon', link: '/certificates/morrow-1-hackathon.pdf' },
];

export type Skill = { name: string; mono: string; note?: string };
export type SkillCategory = { id: string; title: string; subtitle: string; skills: Skill[] };
export const skillCategories: SkillCategory[] = [
  { id: 'languages', title: 'Programming', subtitle: 'Programming languages', skills: [
    { name: 'C', mono: 'C' }, { name: 'C++', mono: 'C+' }, { name: 'Python', mono: 'Py' }, { name: 'Java', mono: 'Jv' },
  ]},
  { id: 'frontend', title: 'Web Technologies', subtitle: 'Frontend development', skills: [
    { name: 'HTML', mono: 'Ht' }, { name: 'CSS', mono: 'Cs' }, { name: 'JavaScript', mono: 'Js' }, { name: 'React', mono: 'Re' },
  ]},
  { id: 'backend', title: 'Frameworks & Backend', subtitle: 'Backend development', skills: [
    { name: 'FastAPI', mono: 'Fa' },
  ]},
  { id: 'infra', title: 'APIs & Tools', subtitle: 'Services and platforms used in projects', skills: [
    { name: 'Groq API', mono: 'Gq' }, { name: 'Cloudinary API', mono: 'Cl' }, { name: 'SerpAPI', mono: 'Sr' }, { name: 'Git / GitHub', mono: 'Gt' }, { name: 'VS Code', mono: 'Vs' }, { name: 'Render', mono: 'Re' }, { name: 'MS Office', mono: 'Of' },
  ]},
  { id: 'fundamentals', title: 'Professional Skills', subtitle: 'Collaboration and problem solving', skills: [
    { name: 'Teamwork', mono: 'Tw' }, { name: 'Communication', mono: 'Co' }, { name: 'Problem-Solving', mono: 'Ps' }, { name: 'Adaptability', mono: 'Ad' }, { name: 'Leadership', mono: 'Ld' }, { name: 'Time Management', mono: 'Tm' },
  ]},
  { id: 'interests', title: 'Interests', subtitle: 'Areas of interest', skills: [
    { name: 'Emerging technologies', mono: 'Et' }, { name: 'Programming', mono: 'Pr' }, { name: 'Logical Reasoning', mono: 'Lr' },
  ]},
];

export type Episode = { code: string; title: string; description: string; tags: string[]; runtime: string; palette: Palette };
export type Season = { number: number; title: string; period: string; synopsis: string; episodes: Episode[] };
export const seasons: Season[] = [
  { number: 1, title: 'The Foundation', period: '2024 – 2028', synopsis: 'B.Tech in Computer Science Engineering at Institute of Technology and Management, GIDA, Gorakhpur.', episodes: [
    { code: 'EP 01', title: 'Computer Science', description: 'Pursuing a Bachelor of Technology in Computer Science Engineering, expected graduation in 2028.', tags: ['B.Tech', 'CSE'], runtime: '2024 – 2028', palette: violet },
  ]},
  { number: 2, title: 'Learning by Building', period: '2025 – 2026', synopsis: 'Web development training and practical student projects.', episodes: [
    { code: 'EP 01', title: 'Web Development Training', description: 'Codec Technologies training covering HTML structure, CSS styling, team collaboration, and layout problem-solving.', tags: ['HTML', 'CSS', 'Teamwork'], runtime: 'Oct – Nov 2025', palette: amber },
    { code: 'EP 02', title: 'DEBUNKIFY', description: 'AI-assisted text/news and image verification project built with React and FastAPI.', tags: ['React', 'FastAPI', 'APIs'], runtime: 'Academic project', palette: crimson },
    { code: 'EP 03', title: 'Notes Heaven', description: 'Responsive AKTU notes website with subject search and organized study resources.', tags: ['HTML', 'CSS', 'JavaScript'], runtime: 'Academic project', palette: ocean },
  ]},
];
export type TopPick = { label: string; title: string; detail: string; palette: Palette };
export const topPicks: TopPick[] = [
  { label: 'Featured project', title: 'DEBUNKIFY', detail: 'AI-assisted fake news and image verification', palette: crimson },
  { label: 'Education', title: 'B.Tech CSE', detail: 'Expected graduation in 2028', palette: violet },
  { label: 'Web platform', title: 'Notes Heaven', detail: 'AKTU notes and study resources', palette: ocean },
  { label: 'Training', title: 'Codec Technologies', detail: 'Web Development Training • 2025', palette: amber },
  { label: 'Programming', title: 'C++', detail: 'Included in technical skills', palette: jade },
];
export type IntroSlide = { kicker: string; title: string; lines: string[]; chips?: string[] };
export const introSlides: IntroSlide[] = [
  { kicker: 'Introduction', title: 'B.Tech · CSE', lines: ['Institute of Technology and Management, GIDA, Gorakhpur', '2024 – 2028 (Expected)'], chips: ['Computer Science Engineering'] },
  { kicker: 'Skills', title: 'Build for the web.', lines: ['C, C++, Python, Java', 'HTML, CSS, JavaScript, React, FastAPI'], chips: ['Programming', 'Web Development', 'APIs'] },
  { kicker: 'Training', title: 'Web Development', lines: ['Codec Technologies Pvt. Ltd.', 'AICTE & ICAC-approved training · Oct – Nov 2025'] },
  { kicker: 'Projects', title: 'Three Projects', lines: ['DEBUNKIFY — text/news and image verification', 'Blood Donation & Acceptance Management System', 'Notes Heaven — AKTU educational notes platform'] },
  { kicker: 'Certifications', title: 'Learning Beyond Class', lines: ['AI for All — TCS iON', 'Cybersecurity job simulations', 'Full-Stack Development 101 — Simplilearn'] },
  { kicker: 'Current mission', title: 'Keep Building', lines: ['Emerging technologies · Programming · Logical Reasoning'] },
];
export type ProfileId = 'durgesh' | 'recruiter' | 'developer' | 'creative';
export type SectionId = 'about' | 'journey' | 'originals' | 'picks' | 'skills' | 'moments' | 'story';
export const viewerProfiles: { id: ProfileId; name: string; blurb: string; color: string; order: SectionId[] }[] = [
  { id: 'durgesh', name: 'Durgesh', blurb: 'The full portfolio, in order', color: '#e5132b', order: ['about', 'journey', 'originals', 'picks', 'skills', 'moments', 'story'] },
  { id: 'recruiter', name: 'Recruiter', blurb: 'Resume, projects & skills first', color: '#4cc9ff', order: ['story', 'moments', 'skills', 'originals', 'about', 'journey', 'picks'] },
  { id: 'developer', name: 'Developer', blurb: 'Projects, stack & GitHub first', color: '#46e3a8', order: ['originals', 'skills', 'journey', 'moments', 'about', 'picks', 'story'] },
  { id: 'creative', name: 'Creative', blurb: 'The story arc & highlights first', color: '#ffb547', order: ['journey', 'picks', 'originals', 'moments', 'about', 'skills', 'story'] },
];
export const sectionMeta: Record<SectionId, { nav: string; card: string; meta: string; palette: Palette }> = {
  about: { nav: 'About', card: 'About Me', meta: 'The Pilot • Education & training', palette: violet },
  journey: { nav: 'Journey', card: 'My Journey', meta: `${seasons.length} Seasons • ${seasons.reduce((n, s) => n + s.episodes.length, 0)} Episodes`, palette: amber },
  originals: { nav: 'Originals', card: 'My Projects', meta: `${projects.length} Projects`, palette: crimson },
  picks: { nav: 'Top Picks', card: 'Highlights', meta: 'Selected portfolio highlights', palette: jade },
  skills: { nav: 'Skills', card: 'My Skills', meta: `${skillCategories.length} Categories`, palette: ocean },
  moments: { nav: 'Moments', card: 'Certifications', meta: `${achievements.length} Highlights • ${certifications.length} Certifications`, palette: crimson },
  story: { nav: 'Resume', card: 'The Full Story', meta: 'Resume • View & download', palette: violet },
};
